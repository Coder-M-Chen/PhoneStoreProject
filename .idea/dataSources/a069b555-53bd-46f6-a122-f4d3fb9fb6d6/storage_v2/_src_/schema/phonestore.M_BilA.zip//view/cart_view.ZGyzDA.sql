CREATE VIEW cart_view AS
  /* ALGORITHM=UNDEFINED */
  SELECT
    `goods`.`GoodsID`   AS `GoodsID`,
    `goods`.`GoodsName` AS `GoodsName`,
    `cart`.`UserId`     AS `UserId`,
    `goods`.`GoodsType` AS `GoodsType`,
    `type`.`TypeName`   AS `TypeName`,
    `cart`.`GoodCount`  AS `GoodCount`,
    `cart`.`GoodPrice`  AS `GoodPrice`,
    `cart`.`GoodSet`    AS `GoodSet`
  FROM `phonestore`.`tb_cart` `cart`
    JOIN `phonestore`.`tb_type` `type`
    JOIN `phonestore`.`tb_goods` `goods`
  WHERE ((`cart`.`GoodId` = `goods`.`GoodsID`) AND (`goods`.`GoodsType` = `type`.`TypeID`) AND
         (`cart`.`GoodCheck` = _utf8'X'));

